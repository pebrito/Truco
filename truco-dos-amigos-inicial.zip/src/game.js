export const SUITS = { paus:'♣', copas:'♥', espadas:'♠', ouros:'♦' };
const RANKS = ['4','5','6','7','Q','J','K','A','2','3'];
export function makeDeck() {
  return Object.entries(SUITS).flatMap(([suit]) => RANKS.map((rank,i)=>({id:`${suit}-${rank}`,suit,rank,value:i})));
}
export function sortHand(hand) { return [...hand].sort((a,b)=>b.value-a.value); }
export function handRank(card, vira) {
  // Regra paulista: manilhas são a carta imediatamente acima da vira.
  const order = ['4','5','6','7','Q','J','K','A','2','3'];
  const next = order[(order.indexOf(vira)+1)%order.length];
  if(card.rank===next) return 100 + ({ouros:4,espadas:3,copas:2,paus:1}[card.suit]);
  return order.indexOf(card.rank);
}
export function nextRoundScore(current, callValue) {
  return Math.min(12, current + callValue);
}
