import React, { useMemo, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, StatusBar, Alert } from 'react-native';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';
import { SUITS, makeDeck, sortHand, handRank, nextRoundScore } from './src/game';

const C = { bg:'#071B16', panel:'#102820', panel2:'#16372D', gold:'#D7B56D', cream:'#F4EBD8', muted:'#A7B8AE', red:'#D85B52', green:'#55B78A' };

function Btn({title,onPress,secondary=false,small=false}) {
  return <TouchableOpacity onPress={onPress} style={[styles.btn, secondary && styles.btnSecondary, small && {paddingVertical:10}]}>
    <Text style={[styles.btnText,secondary && {color:C.gold}]}>{title}</Text>
  </TouchableOpacity>;
}
function Field({value,onChangeText,placeholder,secureTextEntry=false}) {
  return <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#82958A"
    secureTextEntry={secureTextEntry} autoCapitalize="none" style={styles.input}/>;
}
function PlayingCard({card,selected,onPress,small=false}) {
  const red = card.suit === 'copas' || card.suit === 'ouros';
  return <TouchableOpacity onPress={onPress} style={[styles.playingCard, small && styles.smallCard, selected && {transform:[{translateY:-12}],borderColor:C.gold}]}>
    <Text style={[styles.cardRank,{color:red?C.red:'#14231D'}]}>{card.rank}</Text>
    <Text style={{fontSize:small?18:25,color:red?C.red:'#14231D'}}>{SUITS[card.suit]}</Text>
    <Text style={[styles.cardRank,{color:red?C.red:'#14231D',alignSelf:'flex-end',transform:[{rotate:'180deg'}]}]}>{card.rank}</Text>
  </TouchableOpacity>;
}
export default function App() {
  const [screen,setScreen] = useState('welcome');
  const [name,setName] = useState('');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [roomCode,setRoomCode] = useState('');
  const [room,setRoom] = useState('AMIGOS');
  const [score,setScore] = useState([0,0]);
  const [hand,setHand] = useState([]);
  const [played,setPlayed] = useState([]);
  const [selected,setSelected] = useState(null);
  const [round,setRound] = useState(1);
  const [notice,setNotice] = useState('Sua mesa está esperando!');
  const [mode,setMode] = useState('friends');

  const startDemo = () => {
    const deck = makeDeck();
    setHand(sortHand(deck.slice(0,3)));
    setPlayed([]);
    setSelected(null);
    setNotice('Sua vez! Escolha uma carta.');
    setScreen('game');
  };
  const playCard = () => {
    if(selected === null) return Alert.alert('Escolha uma carta','Toque em uma das suas cartas primeiro.');
    const card = hand[selected];
    setPlayed(p=>[...p,{...card,owner:'Você'}]);
    setHand(h=>h.filter((_,i)=>i!==selected));
    setSelected(null);
    setNotice('Carta jogada! Aguardando os outros jogadores...');
  };
  const truco = () => Alert.alert('TRUUUCO! 🔥','Pedido de truco enviado! Na versão online, seus amigos receberão o desafio.');
  const resetMatch = () => {setScore([0,0]);setRound(1);startDemo();};
  const enterApp = () => {
    if(!name.trim()) return Alert.alert('Só falta seu apelido','Digite como seus amigos vão te chamar.');
    setScreen('home');
  };

  return <SafeAreaView style={styles.safe}>
    <ExpoStatusBar style="light"/><StatusBar barStyle="light-content"/>
    {screen==='welcome' && <ScrollView contentContainerStyle={styles.center}>
      <View style={styles.logo}><Text style={{fontSize:44}}>🃏</Text></View>
      <Text style={styles.brand}>TRUCO<Text style={{color:C.gold}}> DOS AMIGOS</Text></Text>
      <Text style={styles.tagline}>SUA TURMA. SUA MESA. SEU TRUCO!</Text>
      <View style={styles.heroCards}><Text style={styles.heroCard}>A♠</Text><Text style={[styles.heroCard,{marginTop:-20}]}>7♥</Text><Text style={styles.heroCard}>Q♦</Text></View>
      <Text style={styles.heading}>A resenha começa aqui.</Text>
      <Text style={styles.sub}>Reúna a galera, monte sua mesa e descubra quem é o verdadeiro pé-quente.</Text>
      <Field value={name} onChangeText={setName} placeholder="Seu apelido"/>
      <Field value={email} onChangeText={setEmail} placeholder="Seu e-mail"/>
      <Field value={password} onChangeText={setPassword} placeholder="Crie uma senha" secureTextEntry/>
      <Btn title="CRIAR MINHA CONTA" onPress={enterApp}/>
      <TouchableOpacity onPress={()=>{setName(name||'Jogador');setScreen('home')}}><Text style={styles.link}>Já tenho uma conta · Entrar</Text></TouchableOpacity>
      <Text style={styles.foot}>Prévia jogável · cadastro demonstrativo</Text>
    </ScrollView>}
    {screen==='home' && <ScrollView contentContainerStyle={styles.page}>
      <View style={styles.top}><View><Text style={styles.eyebrow}>BEM-VINDO À MESA</Text><Text style={styles.heading}>{name || 'Jogador'} 👋</Text></View><View style={styles.avatar}><Text style={{fontSize:22}}>😎</Text></View></View>
      <View style={styles.banner}><Text style={styles.bannerSmall}>TRUCO PAULISTA</Text><Text style={styles.bannerTitle}>Bora jogar?</Text><Text style={styles.sub}>Chame seus amigos e faça a melhor de três virar história.</Text><Btn title="JOGAR AGORA  →" onPress={startDemo}/></View>
      <Text style={styles.section}>JOGAR COM A GALERA</Text>
      <View style={styles.tileRow}><TouchableOpacity style={styles.tile} onPress={()=>setScreen('create')}><Text style={styles.tileIcon}>＋</Text><Text style={styles.tileTitle}>Criar sala</Text><Text style={styles.tileSub}>Monte sua mesa privada</Text></TouchableOpacity>
      <TouchableOpacity style={styles.tile} onPress={()=>setScreen('join')}><Text style={styles.tileIcon}>⌕</Text><Text style={styles.tileTitle}>Entrar na sala</Text><Text style={styles.tileSub}>Use o código do amigo</Text></TouchableOpacity></View>
      <Text style={styles.section}>SEU DESEMPENHO</Text>
      <View style={styles.stats}><View><Text style={styles.statNum}>0</Text><Text style={styles.statLabel}>Vitórias</Text></View><View><Text style={styles.statNum}>0</Text><Text style={styles.statLabel}>Partidas</Text></View><View><Text style={styles.statNum}>—</Text><Text style={styles.statLabel}>Ranking</Text></View></View>
      <Text style={styles.note}>🔒 Salas online, amigos e ranking serão ativados na integração com o servidor.</Text>
    </ScrollView>}
    {screen==='create' && <ScrollView contentContainerStyle={styles.page}><Btn title="← VOLTAR" secondary onPress={()=>setScreen('home')} small/><Text style={styles.heading}>Criar sala</Text><Text style={styles.sub}>Uma mesa só para sua turma.</Text><View style={styles.codeBox}><Text style={styles.eyebrow}>CÓDIGO DA SALA</Text><Text style={styles.code}>{room}</Text><Text style={styles.muted}>Compartilhe este código com seus amigos.</Text></View><Btn title="COPIAR CONVITE" onPress={()=>Alert.alert('Convite',`Código da sala: ${room}`)}/><Btn title="ABRIR MESA DE TESTE" secondary onPress={startDemo}/></ScrollView>}
    {screen==='join' && <View style={styles.page}><Btn title="← VOLTAR" secondary onPress={()=>setScreen('home')} small/><Text style={styles.heading}>Entrar na sala</Text><Text style={styles.sub}>Digite o código que seu amigo compartilhou.</Text><Field value={roomCode} onChangeText={setRoomCode} placeholder="Ex.: ABC123"/><Btn title="ENTRAR NA MESA" onPress={()=>{if(!roomCode.trim())return Alert.alert('Código necessário','Digite o código da sala.');Alert.alert('Sala demonstrativa','A conexão entre jogadores será habilitada no servidor.');}}/></View>}
    {screen==='game' && <View style={styles.gamePage}>
      <View style={styles.gameTop}><TouchableOpacity onPress={()=>setScreen('home')}><Text style={styles.link}>‹ Sair da mesa</Text></TouchableOpacity><Text style={styles.eyebrow}>SALA {room}</Text></View>
      <View style={styles.score}><View><Text style={styles.team}>VOCÊ + PARCEIRO</Text><Text style={styles.points}>{score[0]}</Text></View><View style={{alignItems:'center'}}><Text style={styles.eyebrow}>MÃO {round}</Text><Text style={{color:C.gold,fontSize:20}}>VS</Text></View><View style={{alignItems:'flex-end'}}><Text style={styles.team}>ADVERSÁRIOS</Text><Text style={styles.points}>{score[1]}</Text></View></View>
      <View style={styles.table}><View style={styles.opponent}><Text style={{fontSize:24}}>😎</Text><Text style={styles.playerName}>Parceiro</Text><View style={styles.backCards}><Text>🂠 🂠 🂠</Text></View></View>
        <View style={styles.centerTable}><Text style={styles.tableLabel}>MESA DE TRUCO</Text><View style={styles.playedRow}>{played.map((c,i)=><PlayingCard key={i} card={c} small/>)}</View><Text style={styles.notice}>{notice}</Text></View>
        <View style={styles.opponent}><View style={styles.backCards}><Text>🂠 🂠 🂠</Text></View><Text style={styles.playerName}>Adversário</Text><Text style={{fontSize:24}}>🤠</Text></View></View>
      <Text style={styles.section}>SUAS CARTAS</Text><View style={styles.hand}>{hand.map((c,i)=><PlayingCard key={c.id} card={c} selected={selected===i} onPress={()=>setSelected(i)}/>)}</View>
      <View style={styles.actions}><TouchableOpacity style={styles.trucoBtn} onPress={truco}><Text style={styles.trucoText}>🔥 TRUCO!</Text></TouchableOpacity><TouchableOpacity style={styles.playBtn} onPress={playCard}><Text style={styles.playText}>JOGAR CARTA</Text></TouchableOpacity></View>
      <Text style={styles.note}>Modo demonstração: as cartas são locais, sem adversários conectados.</Text>
      <Btn title="NOVA MÃO" secondary onPress={()=>{setRound(r=>r+1);startDemo()}} small/>
    </View>}
  </SafeAreaView>;
}
const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:C.bg},center:{flexGrow:1,justifyContent:'center',padding:24,alignItems:'center'},
 page:{padding:22,gap:18},gamePage:{flex:1,padding:16,gap:12},logo:{width:84,height:84,borderRadius:26,backgroundColor:C.panel2,alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#456B55',marginBottom:18},
 brand:{fontSize:26,fontWeight:'900',letterSpacing:1.5,color:C.cream},tagline:{color:C.gold,fontSize:10,fontWeight:'800',letterSpacing:2,marginTop:8,marginBottom:22},
 heroCards:{flexDirection:'row',gap:8,marginBottom:18},heroCard:{backgroundColor:C.cream,color:'#173329',fontSize:28,fontWeight:'900',padding:12,borderRadius:10,overflow:'hidden',width:66,height:88,textAlign:'center',textAlignVertical:'center'},
 heading:{fontSize:27,fontWeight:'900',color:C.cream},sub:{fontSize:14,color:C.muted,lineHeight:21,marginTop:-8,marginBottom:8,textAlign:'center'},
 input:{width:'100%',backgroundColor:C.panel,borderWidth:1,borderColor:'#29483C',borderRadius:12,padding:15,color:C.cream,fontSize:15},
 btn:{backgroundColor:C.gold,borderRadius:12,padding:16,alignItems:'center',width:'100%',marginTop:4},btnSecondary:{backgroundColor:'transparent',borderWidth:1,borderColor:C.gold},btnText:{color:'#18271F',fontWeight:'900',letterSpacing:1,fontSize:13},
 link:{color:C.gold,fontWeight:'700',padding:12},foot:{color:'#71877B',fontSize:11,marginTop:14},top:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},eyebrow:{fontSize:10,color:C.gold,fontWeight:'900',letterSpacing:2},avatar:{width:48,height:48,borderRadius:24,backgroundColor:C.panel2,alignItems:'center',justifyContent:'center'},
 banner:{backgroundColor:C.panel2,borderRadius:20,padding:20,borderWidth:1,borderColor:'#315545',gap:12},bannerSmall:{color:C.gold,fontSize:10,fontWeight:'900',letterSpacing:2},bannerTitle:{fontSize:32,fontWeight:'900',color:C.cream},section:{color:C.gold,fontSize:11,fontWeight:'900',letterSpacing:2,marginTop:10},tileRow:{flexDirection:'row',gap:12},tile:{flex:1,backgroundColor:C.panel,borderRadius:16,padding:16,borderWidth:1,borderColor:'#29483C',gap:8},tileIcon:{fontSize:28,color:C.gold},tileTitle:{color:C.cream,fontWeight:'900',fontSize:16},tileSub:{color:C.muted,fontSize:11},stats:{backgroundColor:C.panel,borderRadius:16,padding:18,flexDirection:'row',justifyContent:'space-around'},statNum:{color:C.cream,fontSize:26,fontWeight:'900',textAlign:'center'},statLabel:{color:C.muted,fontSize:11},note:{color:'#81958A',fontSize:10,lineHeight:16,textAlign:'center'},codeBox:{backgroundColor:C.panel,borderRadius:18,padding:24,alignItems:'center',gap:12},code:{fontSize:36,color:C.cream,fontWeight:'900',letterSpacing:8},muted:{color:C.muted,fontSize:12},
 gameTop:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},score:{backgroundColor:C.panel,borderRadius:16,padding:14,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},team:{fontSize:9,color:C.muted,fontWeight:'800'},points:{fontSize:32,color:C.gold,fontWeight:'900'},table:{flex:1,backgroundColor:'#174B35',borderRadius:24,borderWidth:2,borderColor:'#3D7655',padding:12,justifyContent:'space-between',alignItems:'center'},opponent:{alignItems:'center',gap:3},playerName:{color:'#DCE9DF',fontSize:11,fontWeight:'700'},backCards:{backgroundColor:'#102820',padding:7,borderRadius:8},centerTable:{alignItems:'center',width:'100%',gap:10},tableLabel:{color:'#A8C8B0',fontSize:9,letterSpacing:2,fontWeight:'900'},playedRow:{flexDirection:'row',gap:8,minHeight:72,alignItems:'center},notice:{color:'#E2EBDD',fontSize:11,textAlign:'center'},hand:{flexDirection:'row',justifyContent:'center',gap:12,minHeight:108,alignItems:'center'},playingCard:{width:70,height:100,backgroundColor:C.cream,borderRadius:10,padding:7,justifyContent:'space-between',borderWidth:2,borderColor:'#D8D0BE'},smallCard:{width:48,height:68,padding:5},cardRank:{fontSize:17,fontWeight:'900'},actions:{flexDirection:'row',gap:10},trucoBtn:{flex:1,backgroundColor:C.red,padding:15,borderRadius:12,alignItems:'center'},playBtn:{flex:1,backgroundColor:C.gold,padding:15,borderRadius:12,alignItems:'center'},trucoText:{color:'white',fontWeight:'900'},playText:{color:'#18271F',fontWeight:'900',fontSize:11}
});
