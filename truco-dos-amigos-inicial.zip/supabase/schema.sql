-- Execute no SQL Editor do seu projeto Supabase.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null unique,
  avatar_url text,
  wins integer not null default 0,
  losses integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  host_id uuid not null references public.profiles(id),
  status text not null default 'waiting' check (status in ('waiting','playing','finished')),
  variant text not null default 'paulista',
  created_at timestamptz not null default now()
);

create table if not exists public.room_players (
  room_id uuid references public.rooms(id) on delete cascade,
  player_id uuid references public.profiles(id) on delete cascade,
  seat smallint not null check (seat between 0 and 3),
  team smallint not null check (team in (0,1)),
  joined_at timestamptz not null default now(),
  primary key (room_id, player_id),
  unique (room_id, seat)
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id),
  score_team_0 smallint not null default 0,
  score_team_1 smallint not null default 0,
  hand_number integer not null default 1,
  state jsonb not null default '{}'::jsonb,
  status text not null default 'playing',
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_players enable row level security;
alter table public.matches enable row level security;

-- Políticas iniciais: perfis visíveis para jogadores autenticados.
create policy "profiles readable by authenticated" on public.profiles
for select to authenticated using (true);
create policy "players manage own profile" on public.profiles
for all to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "rooms readable by authenticated" on public.rooms
for select to authenticated using (true);
create policy "host creates room" on public.rooms
for insert to authenticated with check (auth.uid() = host_id);
create policy "host updates room" on public.rooms
for update to authenticated using (auth.uid() = host_id);

create policy "room players readable" on public.room_players
for select to authenticated using (true);
create policy "player joins self" on public.room_players
for insert to authenticated with check (auth.uid() = player_id);
create policy "player leaves self" on public.room_players
for delete to authenticated using (auth.uid() = player_id);

create policy "matches readable" on public.matches
for select to authenticated using (true);
-- Atualização de estado da partida deve ser feita por função segura no servidor
-- antes de liberar partidas públicas; não habilite UPDATE irrestrito no cliente.
