# Truco dos Amigos — versão inicial

Aplicativo multiplataforma em React Native + Expo, com identidade visual profissional em verde escuro e dourado.

## O que já está nesta entrega
- Tela de boas-vindas e formulário visual de cadastro (ainda demonstrativo).
- Home/lobby com atalhos para criar e entrar em sala.
- Mesa de demonstração com cartas selecionáveis, placar e botão TRUCO.
- Esqueleto de lógica de baralho e ordenação.
- Esquema SQL inicial para perfis, salas, jogadores e partidas no Supabase.

## Rodar localmente
1. Instale Node.js LTS.
2. Extraia o ZIP e abra a pasta do projeto.
3. Execute `npm install`.
4. Execute `npx expo start`.
5. Use o app Expo Go no Android/iPhone ou abra a versão web com `w`.

## Próximas integrações necessárias
Esta é uma primeira base visual e demonstrativa, não um jogo online publicado. Para liberar partidas reais:
1. Criar projeto no Supabase.
2. Configurar Auth (e-mail/senha) e variáveis de ambiente usando `.env.example`.
3. Implementar criação/entrada de salas com transações no servidor.
4. Implementar motor de regras paulista validado (vira, manilhas, desempates, mão de 11, truco/seis/nove/doze).
5. Implementar sincronização Realtime com validação server-side de cada jogada.
6. Testar partidas em quatro dispositivos e publicar nas lojas.

## Importante
Não coloque a chave `service_role` do Supabase no aplicativo. A lógica de distribuição de cartas e validação de jogadas deve ficar no servidor para impedir trapaças.
